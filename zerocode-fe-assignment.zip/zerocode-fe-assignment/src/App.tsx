export default function App() {
  return <div className='p-4'>Zerocode FE is working!</div>;
}