# ZeroCode Frontend Engineer Assignment

Test Credentials:
- Email: test@example.com
- Password: Test@123

## Setup
```bash
npm install
npm run dev
```
